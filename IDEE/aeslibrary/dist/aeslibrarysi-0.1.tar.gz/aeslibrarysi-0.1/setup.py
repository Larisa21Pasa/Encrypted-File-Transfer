from setuptools import setup, find_packages

setup(
    name='aeslibrarysi',
    version='0.1',
    description='A personalised Python library for encrypt messages with aes.',
    author='Pasa Larisa',
    packages=find_packages(),
)